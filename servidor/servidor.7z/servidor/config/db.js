const mongoose = require('mongoose');
require('dotenv').config({ path: 'variables.env' });

const conectarDB = async () => {  
    //Permite la conexion en forma asincrona
try {
    await mongoose.connect(process.env.DB_MONGO, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        
    })
    console.log("Base CrudProductos CONECTADA !!!");


} catch (error) {
    console.log("La base no se conectó ...");
    console.log(error);

    process.exit(1);  //detenemos la aplicacion.
}
}

module.exports = conectarDB;